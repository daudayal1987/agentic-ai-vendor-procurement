from dataclasses import dataclass
from uuid import UUID, uuid5

from alembic.environment import Any

from app.documents.processing.structure import (
    BlockType,
    DocumentBlock,
    StructuredDocument,
)
from app.documents.processing.sentence import split_sentences

CHUNK_NAMESPACE = UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")


@dataclass(frozen=True)
class DocumentChunk:
    chunk_id: UUID
    document_id: UUID
    tenant_id: UUID
    text: str
    section: str | None
    position: int
    token_count: int
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class ChunkingConfig:
    target_chunk_size: int = 300
    min_chunk_size: int = 100
    max_chunk_size: int = 500
    chunk_overlap: int = 50


def generate_chunk_id(document_id: UUID, position: int) -> UUID:
    return uuid5(
        CHUNK_NAMESPACE,
        f"{document_id}:{position}",
    )


def estimate_token_count(text: str) -> int:
    if not text.strip():
        return 0

    return max(1, len(text.split()))


class SemanticChunker:

    def __init__(self, config: ChunkingConfig | None = None):
        self.config = config or ChunkingConfig()

    def chunk(
        self,
        document: StructuredDocument,
        document_id: UUID,
        tenant_id: UUID,
    ) -> tuple[DocumentChunk, ...]:

        chunks: list[DocumentChunk] = []

        current_parts: list[str] = []
        current_tokens = 0
        current_section: str | None = None

        def flush() -> None:
            nonlocal current_parts
            nonlocal current_tokens
            nonlocal current_section

            if not current_parts:
                return

            text = "\n\n".join(current_parts).strip()

            position = len(chunks)

            chunks.append(
                DocumentChunk(
                    chunk_id=generate_chunk_id(
                        document_id,
                        position,
                    ),
                    document_id=document_id,
                    tenant_id=tenant_id,
                    text=text,
                    section=current_section,
                    position=position,
                    token_count=estimate_token_count(text),
                )
            )

            current_parts = []
            current_tokens = 0

        for block in document.blocks:
            if block.block_type == BlockType.HEADING:
                flush()
                current_section = block.text
                current_parts.append(block.text)
                current_tokens = estimate_token_count(block.text)
                continue

            # FIX: Process the broken-down parts instead of the full block.text
            parts = self._prepare_block_parts(block)
            for part in parts:
                part_tokens = estimate_token_count(part)

                # If adding this part exceeds max size, flush what we have first
                if (
                    current_tokens > 0
                    and current_tokens + part_tokens > self.config.max_chunk_size
                ):
                    flush()

                current_parts.append(part)
                current_tokens += part_tokens

                # If we've reached the target chunk size, flush it
                if current_tokens >= self.config.target_chunk_size:
                    flush()

        flush()
        return tuple(chunks)

    def _split_oversized_block(
        self,
        text: str,
    ) -> tuple[str, ...]:

        sentences = split_sentences(text)

        if not sentences:
            return (text.strip(),)

        return sentences


    def _split_large_sentence(
        self,
        sentence: str,
    ) -> tuple[str, ...]:

        words = sentence.split()

        if len(words) <= self.config.max_chunk_size:
            return (sentence.strip(),)

        parts: list[str] = []

        for start in range(
            0,
            len(words),
            self.config.max_chunk_size,
        ):
            part = " ".join(
                words[
                    start:start + self.config.max_chunk_size
                ]
            )

            if part:
                parts.append(part)

        return tuple(parts)


    def _prepare_block_parts(
        self,
        block: DocumentBlock,
    ) -> tuple[str, ...]:

        block_tokens = estimate_token_count(block.text)

        if block_tokens <= self.config.max_chunk_size:
            return (block.text.strip(),)

        sentences = split_sentences(block.text)

        parts: list[str] = []

        for sentence in sentences:
            parts.extend(
                self._split_large_sentence(sentence)
            )

        return tuple(parts)