from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SourceSegment:
    text: str
    metadata: dict[str, Any]

