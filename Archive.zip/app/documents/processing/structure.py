from dataclasses import dataclass
from enum import StrEnum
import re
from typing import Any


_HEADING_PATTERNS = (
    re.compile(r"^\d+(?:\.\d+)*[\.)]?\s+.+$"),
    re.compile(r"^[A-Z][A-Z0-9\s\-:&/]{2,80}$"),
)

class BlockType(StrEnum):
    HEADING = "heading"
    PARAGRAPH = "paragraph"


@dataclass(frozen=True)
class DocumentBlock:
    block_type: BlockType
    text: str
    position: int
    source_metadata: dict[str, Any]


@dataclass(frozen=True)
class StructuredDocument:
    blocks: tuple[DocumentBlock, ...]


class DocumentStructureDetector:

    def detect(self, text: str, source_metadata: dict[str, Any] = ...) -> StructuredDocument:
        if not text.strip():
            return StructuredDocument(blocks=())

        raw_blocks = re.split(r"\n\s*\n", text)

        blocks: list[DocumentBlock] = []

        for position, raw_block in enumerate(raw_blocks):
            block = raw_block.strip()

            if not block:
                continue

            block_type = (
                BlockType.HEADING
                if self._is_heading(block)
                else BlockType.PARAGRAPH
            )

            blocks.append(
                DocumentBlock(
                    block_type=block_type,
                    text=block,
                    position=len(blocks),
                )
            )

        return StructuredDocument(blocks=tuple(blocks))

    def detect_sources(
    self,
    sources: tuple[SourceText, ...],
) -> StructuredDocument:

    blocks: list[DocumentBlock] = []

    for source in sources:
        cleaned = normalize_text(source.text)

        if not cleaned:
            continue

        structured = self.detect(cleaned)

        for block in structured.blocks:
            blocks.append(
                DocumentBlock(
                    block_type=block.block_type,
                    text=block.text,
                    position=len(blocks),
                    source_metadata=source.metadata,
                )
            )

    return StructuredDocument(
        blocks=tuple(blocks)
    )

    def _is_heading(self, block: str) -> bool:
        lines = block.splitlines()

        # A heading should normally be a single line.
        if len(lines) != 1:
            return False

        text = lines[0].strip()

        for pattern in _HEADING_PATTERNS:
            if pattern.fullmatch(text):
                return True

        return False