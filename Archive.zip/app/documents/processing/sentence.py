import re

_COMMON_ABBREVIATIONS = {
    "mr.",
    "mrs.",
    "ms.",
    "dr.",
    "prof.",
    "e.g.",
    "i.e.",
    "etc.",
    "vs.",
}

# Compile a unified regex pattern for all abbreviations (case-insensitive)
_ABBR_PATTERN = re.compile(
    r"\b(" + "|".join(re.escape(abbr) for abbr in _COMMON_ABBREVIATIONS) + ")",
    re.IGNORECASE
)

def split_sentences(text: str) -> tuple[str, ...]:
    """Split text into sentences using lightweight deterministic rules."""
    if not text.strip():
        return ()

    placeholders: dict[str, str] = {}
    
    # Custom replacement function to preserve original text casing
    def replace_abbr(match: re.Match) -> str:
        matched_text = match.group(0)
        placeholder = f"__ABBR_{len(placeholders)}__"
        placeholders[placeholder] = matched_text
        return placeholder

    # Protect abbreviations using case-insensitive regex
    protected = _ABBR_PATTERN.sub(replace_abbr, text)

    # Split on punctuation boundaries followed by whitespace
    parts = re.split(r"(?<=[.!?])\s+", protected)

    sentences: list[str] = []
    for part in parts:
        sentence = part.strip()
        if not sentence:
            continue

        # Restore original abbreviations with their correct casing
        for placeholder, original_abbr in placeholders.items():
            sentence = sentence.replace(placeholder, original_abbr)

        sentences.append(sentence)

    return tuple(sentences)
