from uuid import uuid4

from app.documents.processing.chunking import (
    ChunkingConfig,
    SemanticChunker,
    estimate_token_count,
    generate_chunk_id,
)
from app.documents.processing.structure import (
    BlockType,
    DocumentBlock,
    StructuredDocument,
)


def test_token_estimation():
    assert estimate_token_count("one two three") == 3


def test_deterministic_chunk_id():
    document_id = uuid4()

    first = generate_chunk_id(document_id, 0)
    second = generate_chunk_id(document_id, 0)

    assert first == second


def test_different_positions_produce_different_ids():
    document_id = uuid4()

    first = generate_chunk_id(document_id, 0)
    second = generate_chunk_id(document_id, 1)

    assert first != second


def test_heading_context_is_preserved():
    document_id = uuid4()
    tenant_id = uuid4()

    document = StructuredDocument(
        blocks=(
            DocumentBlock(
                block_type=BlockType.HEADING,
                text="Payment Terms",
                position=0,
            ),
            DocumentBlock(
                block_type=BlockType.PARAGRAPH,
                text="Vendor shall submit invoices within 15 days.",
                position=1,
            ),
        )
    )

    chunks = SemanticChunker().chunk(
        document=document,
        document_id=document_id,
        tenant_id=tenant_id,
    )

    for chunk in chunks:
        print(f"Chunk ID: {chunk.chunk_id} Chunk {chunk.position}: {chunk.text}")
        print(f"Section: {chunk.section} Token count: {chunk.token_count}")
        print(f"Document ID: {chunk.document_id} Tenant ID: {chunk.tenant_id}")
        print("-" * 40)
        
    assert len(chunks) == 1
    assert chunks[0].section == "Payment Terms"
    assert "Payment Terms" in chunks[0].text
    assert "Vendor shall submit" in chunks[0].text


def test_chunks_are_tenant_and_document_scoped():
    document_id = uuid4()
    tenant_id = uuid4()

    document = StructuredDocument(
        blocks=(
            DocumentBlock(
                block_type=BlockType.PARAGRAPH,
                text="Vendor payment terms.",
                position=0,
            ),
        )
    )

    chunks = SemanticChunker().chunk(
        document=document,
        document_id=document_id,
        tenant_id=tenant_id,
    )

    assert chunks[0].document_id == document_id
    assert chunks[0].tenant_id == tenant_id


def test_chunking_respects_target_size():
    document_id = uuid4()
    tenant_id = uuid4()

    document = StructuredDocument(
        blocks=tuple(
            DocumentBlock(
                block_type=BlockType.PARAGRAPH,
                text="word " * 100,
                position=i,
            )
            for i in range(5)
        )
    )

    config = ChunkingConfig(
        target_chunk_size=200,
        min_chunk_size=50,
        max_chunk_size=250,
        chunk_overlap=0,
    )

    chunks = SemanticChunker(config).chunk(
        document=document,
        document_id=document_id,
        tenant_id=tenant_id,
    )

    assert len(chunks) >= 2


def test_empty_document_produces_no_chunks():
    document = StructuredDocument(blocks=())

    chunks = SemanticChunker().chunk(
        document=document,
        document_id=uuid4(),
        tenant_id=uuid4(),
    )

    assert chunks == ()

def test_oversized_paragraph_is_split_by_sentences():
    document_id = uuid4()
    tenant_id = uuid4()

    text = (
        ("The vendor shall comply with the agreement. " * 40)
    )

    document = StructuredDocument(
        blocks=(
            DocumentBlock(
                block_type=BlockType.PARAGRAPH,
                text=text,
                position=0,
            ),
        )
    )

    config = ChunkingConfig(
        target_chunk_size=50,
        min_chunk_size=10,
        max_chunk_size=80,
        chunk_overlap=0,
    )

    chunks = SemanticChunker(config).chunk(
        document=document,
        document_id=document_id,
        tenant_id=tenant_id,
    )

    assert len(chunks) > 1
    assert all(
        chunk.token_count <= 80
        for chunk in chunks
    )

def test_long_sentence_uses_word_boundary_fallback():
    document_id = uuid4()
    tenant_id = uuid4()

    text = " ".join(["contract"] * 120)

    document = StructuredDocument(
        blocks=(
            DocumentBlock(
                block_type=BlockType.PARAGRAPH,
                text=text,
                position=0,
            ),
        )
    )

    config = ChunkingConfig(
        target_chunk_size=50,
        min_chunk_size=10,
        max_chunk_size=60,
        chunk_overlap=0,
    )

    chunks = SemanticChunker(config).chunk(
        document=document,
        document_id=document_id,
        tenant_id=tenant_id,
    )

    assert len(chunks) > 1
    assert all(
        chunk.token_count <= 60
        for chunk in chunks
    )