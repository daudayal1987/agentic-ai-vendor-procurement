import pytest
from uuid import uuid4

from app.documents.processing.chunking import DocumentChunk
from app.documents.processing.validation import validate_chunks


def test_valid_chunks():
    document_id = uuid4()
    tenant_id = uuid4()

    chunks = (
        DocumentChunk(
            chunk_id=uuid4(),
            document_id=document_id,
            tenant_id=tenant_id,
            text="First chunk",
            section=None,
            position=0,
            token_count=2,
        ),
        DocumentChunk(
            chunk_id=uuid4(),
            document_id=document_id,
            tenant_id=tenant_id,
            text="Second chunk",
            section=None,
            position=1,
            token_count=2,
        ),
    )

    validate_chunks(chunks)


def test_empty_chunk_is_rejected():
    chunk = DocumentChunk(
        chunk_id=uuid4(),
        document_id=uuid4(),
        tenant_id=uuid4(),
        text="",
        section=None,
        position=0,
        token_count=0,
    )

    with pytest.raises(ValueError):
        validate_chunks((chunk,))


def test_duplicate_chunk_id_is_rejected():
    chunk_id = uuid4()
    document_id = uuid4()
    tenant_id = uuid4()

    chunks = (
        DocumentChunk(
            chunk_id=chunk_id,
            document_id=document_id,
            tenant_id=tenant_id,
            text="First",
            section=None,
            position=0,
            token_count=1,
        ),
        DocumentChunk(
            chunk_id=chunk_id,
            document_id=document_id,
            tenant_id=tenant_id,
            text="Second",
            section=None,
            position=1,
            token_count=1,
        ),
    )

    with pytest.raises(ValueError):
        validate_chunks(chunks)