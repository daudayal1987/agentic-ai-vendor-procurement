from app.documents.processing.cleaning import normalize_text


def test_normalize_line_endings():
    text = "Line 1\r\nLine 2\rLine 3"

    result = normalize_text(text)

    assert result == "Line 1\nLine 2\nLine 3"


def test_remove_trailing_whitespace():
    text = "Line 1   \nLine 2\t\nLine 3"

    result = normalize_text(text)

    assert result == "Line 1\nLine 2\nLine 3"


def test_collapse_excessive_blank_lines():
    text = "Section 1\n\n\n\nPayment Terms"

    result = normalize_text(text)

    assert result == "Section 1\n\nPayment Terms"


def test_strip_document_boundaries():
    text = "\n\n  Document content  \n\n"

    result = normalize_text(text)

    assert result == "Document content"


def test_empty_text():
    assert normalize_text("") == ""


def test_preserve_internal_structure():
    text = "Section 1\n\nPayment Terms\nVendor shall pay within 30 days."

    result = normalize_text(text)

    assert result == text